#!/bin/bash
streamlit run --browser.serverAddress $SERVER_NAME --server.port $PORT app.py